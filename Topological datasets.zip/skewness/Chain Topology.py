import csv
from faker import Faker
import random
import sqlite3

fake = Faker()

# SQLite database connection
conn = sqlite3.connect('chain_dataset.db')
cursor = conn.cursor()

# Create table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS Users (
        UserID INTEGER PRIMARY KEY,
        UserName TEXT,
        RegistrationDate DATE
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS Categories (
        CategoryID INTEGER PRIMARY KEY,
        CategoryName TEXT
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS Products (
        ProductID INTEGER PRIMARY KEY,
        ProductName TEXT,
        Price REAL
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS Orders (
        OrderID INTEGER PRIMARY KEY,
        UserID INTEGER,
        OrderDate DATE,
        TotalAmount REAL,
        FOREIGN KEY (UserID) REFERENCES Users(UserID)
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS OrderDetails (
        DetailID INTEGER PRIMARY KEY,
        OrderID INTEGER,
        ProductID INTEGER,
        Quantity INTEGER,
        UnitPrice REAL,
        FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
        FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS Payments (
        PaymentID INTEGER PRIMARY KEY,
        OrderID INTEGER,
        PaymentDate DATE,
        PaymentAmount REAL,
        FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS Addresses (
        AddressID INTEGER PRIMARY KEY,
        UserID INTEGER,
        Address TEXT,
        City TEXT,
        State TEXT,
        Country TEXT,
        FOREIGN KEY (UserID) REFERENCES Users(UserID)
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS ProductCategories (
        AssociationID INTEGER PRIMARY KEY,
        ProductID INTEGER,
        CategoryID INTEGER,
        FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
        FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS Reviews (
        ReviewID INTEGER PRIMARY KEY,
        UserID INTEGER,
        ProductID INTEGER,
        ReviewContent TEXT,
        Rating INTEGER,
        FOREIGN KEY (UserID) REFERENCES Users(UserID),
        FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS UserProductFollow (
        FollowID INTEGER PRIMARY KEY,
        UserID INTEGER,
        ProductID INTEGER,
        FollowDate DATE,
        FOREIGN KEY (UserID) REFERENCES Users(UserID),
        FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
    )
''')

# Commit changes
conn.commit()

# Set skew degree
user_weights = [2]*39067 + [5]*23441 + [10]*15627  # 调整用户表的倾斜程度
product_weights = [5]*15627 + [10]*23441 + [2]*39067  # 调整产品表的倾斜程度
order_weights = [5]*23441 + [10]*31254 + [2]*23440  # 调整订单表的倾斜程度

# Generate data
# Generate Users
users = [{'UserID': i, 'UserName': fake.user_name(), 'RegistrationDate': fake.date_between(start_date='-1y')}
         for i in range(1, 78136)]

# Generate Categories
categories = [{'CategoryID': i, 'CategoryName': fake.word()} for i in range(1, 78136)]

# Generate Products
products = [{'ProductID': i, 'ProductName': fake.word(), 'Price': round(random.uniform(10, 10000), 2)}
            for i in range(1, 78136)]

# Generate Orders
orders = [{'OrderID': i, 'UserID': random.randint(1, 78135),
           'OrderDate': fake.date_between(start_date='-1y'), 'TotalAmount': round(random.uniform(50, 50000), 2)}
          for i in range(1, 78136)]

# Generate OrderDetails
order_details = [{'DetailID': i, 'OrderID': random.randint(1, 78135), 'ProductID': random.randint(1, 78135),
                  'Quantity': random.randint(1, 10), 'UnitPrice': round(random.uniform(10, 100), 2)}
                 for i in range(1, 78136)]

# Generate Payments
payments = [{'PaymentID': i, 'OrderID': random.randint(1, 78135), 'PaymentDate': fake.date_between(start_date='-1y'),
             'PaymentAmount': round(random.uniform(10, 50000), 2)}
            for i in range(1, 78136)]

# Generate Addresses
addresses = [{'AddressID': i, 'UserID': random.randint(1, 78135), 'Address': fake.address(), 'City': fake.city(),
              'State': fake.state(), 'Country': fake.country()}
             for i in range(1, 78136)]

# Generate Categories for Products
product_categories = [{'AssociationID': i, 'ProductID': random.randint(1, 78135), 'CategoryID': random.randint(1, 78135)}
                      for i in range(1, 78136)]

# Generate Reviews
reviews = [{'ReviewID': i, 'UserID': random.randint(1, 78135), 'ProductID': random.randint(1, 78135),
            'ReviewContent': fake.text(), 'Rating': random.randint(1, 5)}
           for i in range(1, 78136)]

# Generate User-Product Follows
user_product_follows = [{'FollowID': i, 'UserID': random.randint(1, 78135), 'ProductID': random.randint(1, 78135),
                        'FollowDate': fake.date_between(start_date='-1y')}
                       for i in range(1, 78136)]

# Insert data
cursor.executemany('INSERT INTO Users VALUES (?, ?, ?)', [(user['UserID'], user['UserName'], user['RegistrationDate']) for user in users])
cursor.executemany('INSERT INTO Categories VALUES (?, ?)', [(category['CategoryID'], category['CategoryName']) for category in categories])
cursor.executemany('INSERT INTO Products VALUES (?, ?, ?)', [(product['ProductID'], product['ProductName'], product['Price']) for product in products])
cursor.executemany('INSERT INTO Orders VALUES (?, ?, ?, ?)', [(order['OrderID'], order['UserID'], order['OrderDate'], order['TotalAmount']) for order in orders])
cursor.executemany('INSERT INTO OrderDetails VALUES (?, ?, ?, ?, ?)', [(detail['DetailID'], detail['OrderID'], detail['ProductID'], detail['Quantity'], detail['UnitPrice']) for detail in order_details])
cursor.executemany('INSERT INTO Payments VALUES (?, ?, ?, ?)', [(payment['PaymentID'], payment['OrderID'], payment['PaymentDate'], payment['PaymentAmount']) for payment in payments])
cursor.executemany('INSERT INTO Addresses VALUES (?, ?, ?, ?, ?, ?)', [(address['AddressID'], address['UserID'], address['Address'], address['City'], address['State'], address['Country']) for address in addresses])
cursor.executemany('INSERT INTO ProductCategories VALUES (?, ?, ?)', [(pc['AssociationID'], pc['ProductID'], pc['CategoryID']) for pc in product_categories])
cursor.executemany('INSERT INTO Reviews VALUES (?, ?, ?, ?, ?)', [(review['ReviewID'], review['UserID'], review['ProductID'], review['ReviewContent'], review['Rating']) for review in reviews])
cursor.executemany('INSERT INTO UserProductFollow VALUES (?, ?, ?, ?)', [(follow['FollowID'], follow['UserID'], follow['ProductID'], follow['FollowDate']) for follow in user_product_follows])

# Submit changes
conn.commit()

# Close connection
conn.close()

# Save data to CSV file
csv_headers = {
    'Users': ['UserID', 'UserName', 'RegistrationDate'],
    'Categories': ['CategoryID', 'CategoryName'],
    'Products': ['ProductID', 'ProductName', 'Price'],
    'Orders': ['OrderID', 'UserID', 'OrderDate', 'TotalAmount'],
    'OrderDetails': ['DetailID', 'OrderID', 'ProductID', 'Quantity', 'UnitPrice'],
    'Payments': ['PaymentID', 'OrderID', 'PaymentDate', 'PaymentAmount'],
    'Addresses': ['AddressID', 'UserID', 'Address', 'City', 'State', 'Country'],
    'ProductCategories': ['AssociationID', 'ProductID', 'CategoryID'],
    'Reviews': ['ReviewID', 'UserID', 'ProductID', 'ReviewContent', 'Rating'],
    'UserProductFollow': ['FollowID', 'UserID', 'ProductID', 'FollowDate']
}

csv_data = {
    'Users': users,
    'Categories': categories,
    'Products': products,
    'Orders': orders,
    'OrderDetails': order_details,
    'Payments': payments,
    'Addresses': addresses,
    'ProductCategories': product_categories,
    'Reviews': reviews,
    'UserProductFollow': user_product_follows
}

for table_name, header in csv_headers.items():
    with open(f'{table_name}.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=header)
        writer.writeheader()
        writer.writerows(csv_data[table_name])