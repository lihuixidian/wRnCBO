SELECT Users.UserName, Orders.OrderID, Products.ProductName
FROM Users
JOIN CentralTable ON Users.UserID = CentralTable.UserID
JOIN Orders ON CentralTable.OrderID = Orders.OrderID
JOIN Products ON CentralTable.ProductID = Products.ProductID
JOIN ProductCategories ON Products.ProductID = ProductCategories.ProductID
JOIN Categories ON ProductCategories.CategoryID = Categories.CategoryID
WHERE Products.ProductName = 'rock' AND Orders.OrderID < 20000;