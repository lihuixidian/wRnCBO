SELECT Users.UserName, UserProductFollow.FollowDate
FROM Users
JOIN CentralTable ON Users.UserID = CentralTable.UserID
JOIN UserProductFollow ON Users.UserID = UserProductFollow.UserID
JOIN Products ON CentralTable.ProductID = Products.ProductID
JOIN ProductCategories ON Products.ProductID = ProductCategories.ProductID
JOIN Categories ON ProductCategories.CategoryID = Categories.CategoryID
JOIN Reviews ON CentralTable.ReviewID = Reviews.ReviewID
WHERE UserProductFollow.FollowDate = '2023-09-13';