SELECT Products.ProductName, COUNT(Reviews.ReviewID) AS TotalReviews, AVG(Reviews.Rating) AS AverageRating
FROM Products
JOIN ProductCategories ON Products.ProductID = ProductCategories.ProductID
JOIN Categories ON ProductCategories.CategoryID = Categories.CategoryID
LEFT JOIN Reviews ON Products.ProductID = Reviews.ProductID
WHERE Products.ProductName = 'window'
GROUP BY Products.ProductName;