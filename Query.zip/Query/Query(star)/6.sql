SELECT Users.UserName, Orders.OrderID, Payments.PaymentDate
FROM Users
JOIN CentralTable ON Users.UserID = CentralTable.UserID
JOIN Orders ON CentralTable.OrderID = Orders.OrderID
JOIN Payments ON CentralTable.PaymentID = Payments.PaymentID
WHERE Orders.OrderID BETWEEN 40000 AND 50000;