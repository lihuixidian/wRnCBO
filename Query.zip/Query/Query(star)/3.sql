SELECT Orders.OrderID, Products.ProductName, OrderDetails.Quantity, Orders.TotalAmount
FROM Orders
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
JOIN ProductCategories ON Products.ProductID = ProductCategories.ProductID
JOIN Categories ON ProductCategories.CategoryID = Categories.CategoryID
WHERE Products.ProductName = 'car' AND Orders.TotalAmount > 2000;