SELECT Orders.OrderID, Products.ProductName, OrderDetails.Quantity
FROM Orders
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
JOIN Addresses ON Orders.OrderID = Addresses.UserID
WHERE OrderDetails.Quantity >= 8;