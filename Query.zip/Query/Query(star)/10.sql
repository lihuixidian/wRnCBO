SELECT Orders.OrderID, Orders.TotalAmount, Products.ProductName, Users.UserName
FROM Orders
JOIN CentralTable ON Orders.OrderID = CentralTable.OrderID
JOIN Products ON CentralTable.ProductID = Products.ProductID
JOIN Users ON CentralTable.UserID = Users.UserID
WHERE Orders.TotalAmount > 10000 AND Orders.OrderID < 20000;