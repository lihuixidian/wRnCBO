SELECT Users.UserName, Orders.OrderID, Orders.OrderDate, Products.ProductName, OrderDetails.Quantity, OrderDetails.UnitPrice
FROM Users
JOIN Orders ON Users.UserID = Orders.UserID
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
WHERE unitprice > 50.0 AND quantity > 8
ORDER BY Orders.OrderDate DESC;