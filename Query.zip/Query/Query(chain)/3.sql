SELECT Users.UserName, Products.ProductName, Orders.OrderDate, Payments.PaymentDate, Payments.PaymentAmount
FROM Users
JOIN Orders ON Users.UserID = Orders.UserID
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
LEFT JOIN Payments ON Orders.OrderID = Payments.OrderID
WHERE username = 'elizabethmata';