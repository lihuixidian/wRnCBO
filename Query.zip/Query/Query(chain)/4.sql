SELECT Users.UserName, Products.ProductName, Categories.CategoryName
FROM Users
JOIN UserProductFollow ON Users.UserID = UserProductFollow.UserID
JOIN Products ON UserProductFollow.ProductID = Products.ProductID
JOIN ProductCategories ON Products.ProductID = ProductCategories.ProductID
JOIN Categories ON ProductCategories.CategoryID = Categories.CategoryID
WHERE categoryname = 'health';