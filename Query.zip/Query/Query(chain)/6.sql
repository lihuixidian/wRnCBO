SELECT Products.ProductName, Reviews.ReviewContent, Reviews.Rating, Users.UserName, Users.RegistrationDate
FROM Products
JOIN Reviews ON Products.ProductID = Reviews.ProductID
LEFT JOIN Users ON Reviews.UserID = Users.UserID
WHERE Users.UserName = 'hunterbarry' AND Reviews.Rating >= 3;