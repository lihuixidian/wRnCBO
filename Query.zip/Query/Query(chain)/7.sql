SELECT Orders.OrderID, Payments.PaymentID, Payments.PaymentDate, Addresses.Address, Addresses.City, Addresses.State, Addresses.Country
FROM Orders
LEFT JOIN Payments ON Orders.OrderID = Payments.OrderID
LEFT JOIN Addresses ON Orders.UserID = Addresses.UserID
WHERE Orders.OrderID > 70000 and Payments.PaymentID > 50000;