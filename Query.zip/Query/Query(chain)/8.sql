SELECT Users.UserName, Products.ProductName, Reviews.ReviewContent, Reviews.Rating
FROM Users
JOIN UserProductFollow ON Users.UserID = UserProductFollow.UserID
JOIN Products ON UserProductFollow.ProductID = Products.ProductID
LEFT JOIN Reviews ON Products.ProductID = Reviews.ProductID
WHERE Users.UserName = 'connie72' AND Reviews.Rating IS NOT NULL;