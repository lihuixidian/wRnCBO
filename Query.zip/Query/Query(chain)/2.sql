SELECT Products.ProductName, Categories.CategoryName, Reviews.ReviewContent, Reviews.Rating
FROM Products
JOIN ProductCategories ON Products.ProductID = ProductCategories.ProductID
JOIN Categories ON ProductCategories.CategoryID = Categories.CategoryID
LEFT JOIN Reviews ON Products.ProductID = Reviews.ProductID
WHERE Categories.CategoryName = 'information';