SELECT Users.UserName, Orders.OrderID, Orders.OrderDate, OrderDetails.ProductID, Products.ProductName, OrderDetails.Quantity
FROM Users
JOIN Orders ON Users.UserID = Orders.UserID
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
WHERE Orders.OrderDate = '2023-06-02' AND OrderDetails.ProductID > 40000;