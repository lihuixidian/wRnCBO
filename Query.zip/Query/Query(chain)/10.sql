SELECT Users.UserName, Categories.CategoryName, Products.ProductName, COUNT(*) AS PurchaseCount
FROM Users
JOIN Orders ON Users.UserID = Orders.UserID
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
JOIN ProductCategories ON Products.ProductID = ProductCategories.ProductID
JOIN Categories ON ProductCategories.CategoryID = Categories.CategoryID
WHERE username = 'barberchristopher'
GROUP BY Users.UserName, Categories.CategoryName, Products.ProductName
ORDER BY PurchaseCount DESC
LIMIT 10;