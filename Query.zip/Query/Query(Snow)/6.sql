SELECT Users.UserName, COUNT(Orders.OrderID) AS OrderCount, SUM(Payments.PaymentAmount) AS TotalPayment
FROM Users
JOIN Orders ON Users.UserID = Orders.UserID
JOIN Payments ON Orders.OrderID = Payments.OrderID
GROUP BY Users.UserName;