SELECT Categories.CategoryName, Products.ProductName, SUM(OrderDetails.Quantity) AS TotalSales
FROM Categories
JOIN ProductCategories ON Categories.CategoryID = ProductCategories.CategoryID
JOIN Products ON ProductCategories.ProductID = Products.ProductID
JOIN OrderDetails ON Products.ProductID = OrderDetails.ProductID
WHERE categoryname = 'a' AND productname = 'commercial'
GROUP BY Categories.CategoryName, Products.ProductName;