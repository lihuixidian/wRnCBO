SELECT Products.ProductName, SUM(OrderDetails.Quantity) AS TotalQuantity, SUM(OrderDetails.UnitPrice * OrderDetails.Quantity) AS TotalSales
FROM Products
JOIN OrderDetails ON Products.ProductID = OrderDetails.ProductID
WHERE OrderDetails.Quantity > 5 AND Products.ProductName LIKE '%nation%'
GROUP BY Products.ProductName;