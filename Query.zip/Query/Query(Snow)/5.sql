SELECT Users.UserName, Reviews.ReviewContent, Reviews.Rating
FROM Users
JOIN Reviews ON Users.UserID = Reviews.UserID
WHERE reviewcontent LIKE 'Follow%'
ORDER BY Reviews.Rating DESC;