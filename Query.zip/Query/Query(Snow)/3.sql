SELECT Orders.OrderID, Users.UserName, Products.ProductName, Orders.OrderDate
FROM Orders
JOIN Users ON Orders.UserID = Users.UserID
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
WHERE username = 'margaret46' AND Orders.OrderID > 20000;