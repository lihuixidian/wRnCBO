SELECT Users.UserName, Addresses.Address, Addresses.City
FROM Users
JOIN Addresses ON Users.UserID = Addresses.UserID
WHERE Addresses.City = 'Michaelhaven';