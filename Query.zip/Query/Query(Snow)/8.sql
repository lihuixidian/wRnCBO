SELECT Users.UserName, Products.ProductName, SUM(OrderDetails.Quantity) AS PurchaseQuantity
FROM Users
JOIN Orders ON Users.UserID = Orders.UserID
JOIN OrderDetails ON Orders.OrderID = OrderDetails.OrderID
JOIN Products ON OrderDetails.ProductID = Products.ProductID
WHERE productname = 'stock'
GROUP BY Users.UserName, Products.ProductName;