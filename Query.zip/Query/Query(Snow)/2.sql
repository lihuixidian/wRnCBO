SELECT Users.UserName, Products.ProductName, UserProductFollow.FollowDate
FROM Users
JOIN UserProductFollow ON Users.UserID = UserProductFollow.UserID
JOIN Products ON UserProductFollow.ProductID = Products.ProductID
WHERE UserProductFollow.FollowDate = '2023-12-18'
ORDER BY UserProductFollow.FollowDate DESC;