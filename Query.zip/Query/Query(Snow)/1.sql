SELECT Users.UserName, COUNT(Orders.OrderID) AS OrderCount, SUM(Orders.TotalAmount) AS TotalAmount
FROM Users
JOIN Orders ON Users.UserID = Orders.UserID
WHERE totalamount > 10000
GROUP BY Users.UserName;